package com.example.demo.book.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.book.Entity.Book;


public interface Bookrepo extends JpaRepository<Book,Long>{

}
