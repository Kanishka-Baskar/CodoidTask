package com.example.demo.book.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.book.Entity.Book;
import com.example.demo.book.Repository.Bookrepo;

@Service
public class BookIMPL implements BookService{

	@Autowired
	private Bookrepo bookrepo;
	
	@Override
	public Book newbook(Book book) {
		return bookrepo.save(book);
	}
	
	@Override
	public List<Book> allbooks(){
		return bookrepo.findAll();
	}
	
	@Override
	public Book specificbook(Long id) {
		return bookrepo.findById(id).orElse(null);
	}
	
	@Override
	public List<Book> deletebook(Long id){
		bookrepo.deleteById(id);
		return bookrepo.findAll();
	}
}
