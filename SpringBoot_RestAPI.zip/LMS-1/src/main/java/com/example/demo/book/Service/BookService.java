package com.example.demo.book.Service;

import java.util.List;

import com.example.demo.book.Entity.Book;

public interface BookService {

	public Book newbook(Book book);
	
	public List<Book> allbooks();
	
	public Book specificbook(Long id);
	
	public List<Book> deletebook(Long id);
	

}
