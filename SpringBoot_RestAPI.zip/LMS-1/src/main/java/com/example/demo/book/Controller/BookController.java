package com.example.demo.book.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.book.Entity.Book;
import com.example.demo.book.Service.BookService;

@RestController
public class BookController {

	@Autowired
	private BookService bookservice;
	
	@PostMapping("/newbook")
	public Book newbook(@RequestBody Book book) {
		Book newbooks=bookservice.newbook(book);
		return newbooks;
	}
	
	@GetMapping("/allbooks")
	public List<Book> allbooks(){
		List<Book> allbooks=bookservice.allbooks();
		return allbooks;
	}
	
	@GetMapping("/{id}")
	public Book specificbook(@PathVariable Long id) {
		Book specificbookbyid=bookservice.specificbook(id);
		return specificbookbyid;
	}
	
	@DeleteMapping("/{id}")
	public List<Book> deletebook(@PathVariable Long id){
		List<Book> deletedbook=bookservice.deletebook(id);
		return deletedbook;
	}
	
}
