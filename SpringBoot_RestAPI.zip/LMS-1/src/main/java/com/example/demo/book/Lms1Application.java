package com.example.demo.book;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lms1Application {

	public static void main(String[] args) {
		SpringApplication.run(Lms1Application.class, args);
	}

}
